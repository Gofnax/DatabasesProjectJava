package hairDressingSalon;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Objects;

import nimrodBarHairDressingSalon.Shift;
import nimrodBarHairDressingSalon.vipClient;

public class Shift {
	private LocalDate date;
	private LocalTime startHour;
	private LocalTime endHour;
	private final int coffeAndPastry = 10;
	private HairDresser[] hairDressers;
	private Treatment[] allTreatments;
	private int numOfHD;
	private int numOfTreatments;

	public Shift(LocalDate date, LocalTime startHour, LocalTime endHour, int numOfHDForShift,
			int numOfBookedTreatments) {
		this.date = date;
		this.startHour = startHour;
		this.endHour = endHour;
		this.hairDressers = new HairDresser[numOfHDForShift];
		this.allTreatments = new Treatment[numOfBookedTreatments];
		this.numOfHD = 0;
		this.numOfTreatments = 0;
	}

	public int getNumOfHD() {
		return this.numOfHD;
	}

	public int getNumOfTreatments() {
		return this.numOfTreatments;
	}

	public LocalDate getDate() {
		return this.date;
	}

	public LocalTime getStartHour() {
		return this.startHour;
	}

	public LocalTime getEndHour() {
		return this.endHour;
	}

	public boolean isHDExist(HairDresser hd) {
		for (int i = 0; i < numOfHD; i++) {
			if (hairDressers[i].getHDName.equals(hd.getHdName))
				return true;
		}
		return false;
	}

	public boolean isTreatmentExist(Treatment t) {
		for (int i = 0; i < numOfTreatments; i++) {
			if (allTreatments[i].compareTo(t) == 0)
				return true;
		}
		return false;
	}

	public boolean addHDToShift(HairDresser hd) {
		if (isHDExist(hd)) {
			return false;
		}

		if (this.numOfHD == this.hairDressers.length) {
			this.hairDressers = Arrays.copyOf(hairDressers, hairDressers.length + 1);
		}

		hairDressers[numOfHD++] = hd;
		return true;
	}

	public boolean addTreatmentToShift(Treatment t) {
		if (isTreatmentExist(t)) {
			return false;
		}

		if (this.numOfTreatments == this.allTreatments.length) {
			this.allTreatments = Arrays.copyOf(allTreatments, allTreatments.length + 1);
		}

		allTreatments[numOfTreatments++] = t;
		Arrays.sort(allTreatments);
		return true;
	}

	public int calcDailyProfit() {
		int totalProfits = 0;
		for (int i = 0; i < numOfTreatments; i++) {
			totalProfits += this.allTreatments[i].getPrice();
			if (this.allTreatments[i].getCustomer() instanceof vipCustomer) {
				totalProfits -= coffeAndPastry;
			}
		}

		for (int i = 0; i < this.numOfHD; i++) {
			if (hairDressers[i] instanceof Senior) {
				totalProfits -= coffeAndPastry;
			}
			return totalProfits;
		}
	}

	@Override
	public String toString() {
		int profits = calcDailyProfit();
		StringBuffer sb = new StringBuffer("Shift in " + this.date.toString());
		sb.append("start at: " + this.startHour.toString()).append("\nends at: " + this.endHour.toString());
		sb.append("\nThere are " + this.numOfHD + "in the shift and their name's are: ");
		for (int i = 0; i < this.numOfHD; i++) {
			sb.append("\n").append(hairDressers[i].getHdName());
		}
		sb.append("\n").append("There are " + this.numOfTreatments + " today and their kinds are:");
		for (int i = 0; i < numOfTreatments; i++) {
			sb.append("\n").append(allTreatments[i].type);
		}
		sb.append("\nThe profits of the day are: " + profits);
		return sb.toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Shift)) {
			return false;
		}

		Shift temp = (Shift) obj;
		return ((Arrays.equals(this.allTreatments, temp.hairDressers))
				&& (Arrays.equals(this.allTreatments, temp.allTreatments)) && (this.startHour == temp.startHour)
				&& (this.endHour == temp.endHour) && (this.date == temp.date)
				&& (this.calcDailyProfit() == temp.calcDailyProfit()));
	}

}
